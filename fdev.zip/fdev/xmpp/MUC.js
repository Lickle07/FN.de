module.exports = class MUC {

}